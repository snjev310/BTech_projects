<html>
<head>
<script>
function color()
{
    
    document.getElementById('a').style.backgroundColor='red';
}
function color1()
{
    
    document.getElementById('a').style.backgroundColor='green';
}

</script>
</head>
<body id="a">

<h1 id="demo">hello</h1>
<button type="button" onclick="color()" style="background-color: red;">&nbsp;</button>
<button type="button" onclick="color1()" style="background-color: green;">&nbsp;</button>
</body>
</html>




