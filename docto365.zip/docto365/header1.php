</div>
                <div class="arrow-down"></div>
            </div>
        </div>
    </section>
    
<section class="menu-media">
  <div class="menu-content">
    <div class="logo">Docto 365</div>
      <div class="icon"><a href="#"><img src="img/icons/menu-media.png"/></a></div>
  </div>
</section>

<section class="menu">
    <div class="menu-content">
        <div class="logo"><img src="logo.jpg" height="85" width="90"/></div>
            <ul id="menu">