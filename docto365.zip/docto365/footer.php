<section class="footer">
    
      <div class="margin">
      
        <div class="menu-footer">
        
        <a href="home.php" target="_self">Home</a>
        
        <a href="https://www.facebook.com/Docto365/?hc_ref=SEARCH&fref=nf" target="_blank">Facebook</a>
        
        </div>
        
          <div class="copyright">DOCTO 365</div>        
     </div>
    </section>    
</div>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="js/jquery.parallax.js"></script>
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/jquery.sticky.js"></script> 
	<script src="js/script.js"></script>

</body>
</html>