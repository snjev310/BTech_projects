<head>
    <title>Docto 365</title>
    <link rel="icon" href="favicon.png">
    <link rel="stylesheet" type="text/css" href="css/reset.css">
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/style-responsive.css" />
</head>
<body>
<div classs="container">
    <section class="start-page parallax-background" id="home">
        <div class="opacity">
            <div class="content">
                <div class="text">
                    <h2><font color="white"></font></h2>
                    <h1>
                        Welcome to<br /> <span>Docto 365</span>
                    </h1>
                    <p>Caring for life</p>