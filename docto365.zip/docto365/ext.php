<section class="footer">
    
      <div class="margin">
      
        <div class="menu-footer">
        
        <a href="#home">Home</a>
        
        <a href="https://www.facebook.com/Docto365/?hc_ref=SEARCH&fref=nf">Facebook</a>
        
        </div>
        
          <div class="copyright">DOCTO 365</div>        
     </div>
    </section> 
</div>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="js/jquery.parallax.js"></script>
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/jquery.sticky.js"></script> 
	<script src="js/script.js"></script>
</body>

</html>



<head>
<title>Docto 365</title>
    <link rel="icon" href="favicon.png">
    <link rel="stylesheet" type="text/css" href="css/reset.css">
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/style-responsive.css" />
</head>
<body>
<div class="container">
    <section class="start-page parallax-background" id="home">
        <div class="opacity">
            <div class="content">
                <div class="text">
                    <h2><font color="white"></font></h2>
                    <h1>
                        Welcome to<br /> <span>Docto 365</span>
                    </h1>
                    <p>Caring for life</p>
					
					
					
</div>
                <div class="arrow-down"></div>
            </div>
        </div>
    </section>

  <section class="menu-media">
  <div class="menu-content">
    <div class="logo">Docto 365</div>
      <div class="icon"><a href="#"><img src="img/icons/menu-media.png"/></a></div>
  </div>
</section>
<section class="menu">
    <div class="menu-content">
        <div class="logo"><img src="logo.jpg" height="80" width="90"/></div>
            <ul id="menu">
			
			
			
<head>

<title>Docto 365</title>
    <link rel="icon" href="favicon.png">
    <link rel="stylesheet" type="text/css" href="css/reset.css">
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/style-responsive.css" />
</head>
<body>
<div class="container">
    <section class="start-page parallax-background" id="home">
        <div class="opacity">
            <div class="content">
                <div class="text">
                    <h2><font color="white"></font></h2>
                    <h1>
                        Welcome to<br /> <span>Docto 365</span>
                    </h1>
                    <p>Caring for life</p>
					
					
</div>
                <div class="arrow-down"></div>
            </div>
        </div>
    </section>

  <section class="menu-media">
  <div class="menu-content">
    <div class="logo">Docto 365</div>
      <div class="icon"><a href="#"><img src="img/icons/menu-media.png"/></a></div>
  </div>
</section>
<section class="menu">
    <div class="menu-content">
        <div class="logo"><img src="logo.jpg" height="80" width="90"/></div>
            <ul id="menu">
			
			
 <section class="footer">
    
      <div class="margin">
      
        <div class="menu-footer">
        
        <a href="#home">Home</a>
        
        <a href="https://www.facebook.com/Docto365/?hc_ref=SEARCH&fref=nf">Facebook</a>
        
        </div>
        
          <div class="copyright">DOCTO 365</div>        
     </div>
    </section> 
</div>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="js/jquery.parallax.js"></script>
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/jquery.sticky.js"></script> 
	<script src="js/script.js"></script>
</body>

</html>
