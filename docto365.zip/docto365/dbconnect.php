<?php
define('HOST','localhost');
define('USER','root');
define('PASS','');
define('db','docto365');
$con=mysqli_connect(HOST,USER,PASS,db) or die('unable to connect');
?>